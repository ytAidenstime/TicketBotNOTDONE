import Eris from "eris"

let token = "BOTTOKEN" // here is where you put the bots token
let pre = "!" // here is where you put the bots prefix
let supportrole = "roleID" // (not working yet) here is where you put the bots support team role, this is the role that lets people see the channel to assit with tickets


const client = new Eris(token, {
    intents: [
        "guilds",
        "guildMessages",
        "MESSAGE_CONTENT"
    ]
});

client.on('ready', () => {
    console.log('ready!')
});

client.on("messageCreate", (message) => {
    if (message.author.bot) {
    console.log("message was from bot so didnt reply");
        } else {
          if (message.content === pre + "createticket") {
              client.createChannel('959874908861640765', "test"); {
                  client.createMessage(message.channel.id, "okey your ticket was made please go to the channel to be helped")
        }
      }  
    }
})

client.on('messageCreate', (message) => {
    if (message.content === pre + 'close') {
    if (message.member.permissions.has('administrator')) {
        client.createMessage(message.channel.id, "okey closing ticket in 1sec or less")
        let ticketchannel = message.channel
        client.deleteChannel(ticketchannel.id)
        } else {
           client.createMessage(message.channel.id, "you do not have permission to close this ticket")
        }
    }
})


client.connect();